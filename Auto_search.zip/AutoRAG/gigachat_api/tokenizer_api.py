from typing import Union, List
from urllib.parse import urljoin

import os
import sys 
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))


#tokenizer = TokenizerV1Client(settings=devices_settings, model_name='GigaChat')
#print(tokenizer.encode('query'))